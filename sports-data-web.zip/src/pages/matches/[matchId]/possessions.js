import React from 'react'

const possessions = () => {
  return (
    <div>possessions</div>
  )
}

export default possessions