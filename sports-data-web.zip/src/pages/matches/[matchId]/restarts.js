import React from 'react'

const restarts = () => {
  return (
    <div>restarts</div>
  )
}

export default restarts