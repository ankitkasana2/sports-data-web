import React from 'react'

const lineups = () => {
  return (
    <div>lineups</div>
  )
}

export default lineups