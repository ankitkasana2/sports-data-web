import React from 'react'

const events = () => {
  return (
    <div>events</div>
  )
}

export default events